# Docx Reporting in OSGi context

TODO : explain it.
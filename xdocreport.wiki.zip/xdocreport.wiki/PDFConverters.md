# ODF Converters

## ODT Converters

### Stable ODT Converters

Here the list of XDocReport fr.opensagres.xdocreport.converter.**IConverter** implemented for odt which can be used with ConverterRegistry :

<table>
  <tr><td>Output format</td><td>OSGi fragment</td><td>Dependencies</td><td>Status</td></tr>
  <tr><td>XHTML</td><td>[fr.opensagres.xdocreport.converter.odt.odfdom](http://code.google.com/p/xdocreport/source/browse/#git%2Fconverter%2Ffr.opensagres.xdocreport.converter.odt.odfdom)</td><td>[ODF-DOM Converter](http://code.google.com/p/xdocreport/wiki/ODFDOMConverter)</td><td></td><td>Stable</td></tr>
  <tr><td>PDF</td><td>[fr.opensagres.xdocreport.converter.odt.odfdom](http://code.google.com/p/xdocreport/source/browse/#git%2Fconverter%2Ffr.opensagres.xdocreport.converter.odt.odfdom)</td><td>[ODF-DOM Converter](http://code.google.com/p/xdocreport/wiki/ODFDOMConverter) with iText</td><td></td><td>Stable</td></tr>
</table>

Here converters uses [ODF-DOM Converter](http://code.google.com/p/xdocreport/wiki/ODFDOMConverter) which loads odt in Java Structure ODFDOM org.odftoolkit.odfdom.doc.**OdfDocument** and generation is done by using this model. 

Please read [Download](http://code.google.com/p/xdocreport/wiki/Download) section to use those converters.

### Expermimental ODT Converters

Those converter are just expermiental.

<table>
  <tr><td>ID</td><td>Output format</td><td>OSGi fragment</td><td>Status</td></tr>
  <tr><td>ODT 2 PDF via FOP</td><td>PDF</td><td>[fr.opensagres.xdocreport.converter.fop.odt](http://code.google.com/p/xdocreport/source/browse/#git%2Fsandbox%2Ffr.opensagres.xdocreport.converter.fop.odt)</td><td>Experimental</td></tr>
  <tr><td>ODT 2 FO via XSL-FO</td><td>FO</td><td>[fr.opensagres.xdocreport.converter.fop.odt](http://code.google.com/p/xdocreport/source/browse/#git%2Fsandbox%2Ffr.opensagres.xdocreport.converter.fop.odt)</td><td>Experimental</td></tr>
  <tr><td>ODT 2 XHTML via XSL</td><td>XHTML</td><td>[fr.opensagres.xdocreport.converter.fop.odt](http://code.google.com/p/xdocreport/source/browse/#git%2Fsandbox%2Ffr.opensagres.xdocreport.converter.fop.odt)</td><td>Experimental</td></tr>
</table>

Here converters use XSL to transform content.xml (by using styles.xml) from the odt to FO or XHTML. 

"ODT 2 PDF via FOP" converter are a litlle slowly because steps are odt -> XSL-FO -> FO -> FOP. So we decided to give our energy to develop "ODT 2 PDF via ODFDOM-IText". 
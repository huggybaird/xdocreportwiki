# Velocity - XML Context

Use [Velocity Anakia](http://velocity.apache.org/engine/devel/anakia.html) by registering a JDOM Document in the Java context.

TODO: explain more.
# Add XDocReport JARs in your project
XDocReport is modular and you can add only the modules that your require to your project. There are some core modules which should be always included and some other modules that depend on what kind of source document (ODT or DOCX) and which template engine you decided to use.

In any case you may either copy the JAR files directly or use build tools like Gradle to provide the dependency for you from [Maven Central Repository](http://search.maven.org/#search%7Cga%7C1%7Cg%3A%22fr.opensagres.xdocreport%22).

## Core Modules

For any document type and template engine you need to add at least following JARs : 

<table>
  <tr><td>**JARs name**</td><td>**Description**</td><td>**OSGi Bundle/Fragment**</td></tr>
  <tr><td>fr.opensagres.xdocreport.core</td><td>XDocReport Core</td><td>Bundle</td></tr>
  <tr><td>fr.opensagres.xdocreport.document</td><td>Document type API</td><td>Bundle</td></tr>
  <tr><td>fr.opensagres.xdocreport.template</td><td>Template engine API</td><td>Bundle</td></tr>
  <tr><td>fr.opensagres.xdocreport.converter</td><td>Converter API</td><td>Bundle</td></tr>
</table>





## Docx Source Document Modules
If you are going to use DOCX as document source for your report, so you need to include following modules too: 

<table>
  <tr><td>**JARs name**</td><td>**Description**</td><td>**OSGi Bundle/Fragment**</td></tr>
  <tr><td>fr.opensagres.xdocreport.document.docx</td><td>Docx Document implementation</td><td>Fragment -> fr.opensagres.xdocreport.document</td></tr>
</table>

**Note for OSGi**: this JAR is a fragment linked to the bundle OSGi `fr.opensagres.xdocreport.document`.


## ODT Source Document Modules
If you are going to use ODT as document source for your report, so you need to include following modules too: 

<table>
  <tr><td>*JARs name*</td><td>*Description*</td><td>*OSGi Bundle/Fragment*</td></tr>
  <tr><td>fr.opensagres.xdocreport.document.odt</td><td>ODT Document implementation</td><td>Fragment -> fr.opensagres.xdocreport.document</td></tr>
</table>

**Note for OSGi**: this JAR is a fragment linked to the bundle OSGi `fr.opensagres.xdocreport.document`.


## Velocity JARs

If Velocity is your choice of template engine, you have to include Velocity template interface as well as Velocity library itself too.

### Velocity Template Interface

Add Velocity template engine interface module: 

<table>
  <tr><td>*JARs name*</td><td>*Description*</td><td>*OSGi Bundle/Fragment*</td></tr>
  <tr><td>fr.opensagres.xdocreport.template.velocity</td><td>Velocity template engine implementation</td><td>Fragment -> fr.opensagres.xdocreport.template</td></tr>
</table>

**Note for OSGi**: this JAR is a fragment linked to the bundle OSGi `fr.opensagres.xdocreport.template`.

### Velocity Library

Add Velocity JARs: 

<table>
  <tr><td>*JARs name*</td><td>*Description*</td></tr>
  <tr><td>velocity-1.7</td><td>Velocity</td></tr>
  <tr><td>commons-collections-3.2.1</td><td>Commons Collection</td></tr>
  <tr><td>commons-lang-2.4</td><td>Commons Lang</td></tr>
  <tr><td>oro-2.0.8</td><td>ORO</td></tr>
</table>
XDocReport uses template engine to replace values, manage loop, condition... from the designed report (odt, docx...) to generate report.

XDocReport implements 2 template engine : 

 - [Velocity](VelocityTemplate)
 - [Freemarker](FreemarkerTemplate)
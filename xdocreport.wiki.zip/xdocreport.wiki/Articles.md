Here some articles about XDocReport : 

 - [How to convert docx/odt to pdf/html with Java?](http://angelozerr.wordpress.com/2012/12/06/how-to-convert-docxodt-to-pdfhtml-with-java/)
 - [PDF Templating with XDocReport](http://www.blackpepper.co.uk/posts/pdf-templating-with-docxreport/)
 - [Generating PDF files using ODT/DOCX templates](https://vaadin.com/blog/-/blogs/generating-pdf-files-using-odt-docx-templates)
 - [Merging odf files using XDocReport and XPages](http://blog.redturtle.it/2013/03/08/merging-odf-files-using-xdocreport-and-xpages)
 - [Approaches to document/report generation](http://fr.slideshare.net/plutext/document-generation-2012osdcsydney)
 - [Merge Word Document using XDocReport](http://www.sambhashanam.com/tag/merge-word-document-using-xdocreport/) :
  - [Mail merge in java for Microsoft Word document – Part I](http://www.sambhashanam.com/mail-merge-in-java-for-microsoft-word-document-part-i/)
  - [Mail merge in java for Microsoft Word document and convert to PDF without iText – Part II](http://www.sambhashanam.com/mail-merge-in-java-for-microsoft-word-document-and-convert-to-pdf-without-itext-part-ii/)
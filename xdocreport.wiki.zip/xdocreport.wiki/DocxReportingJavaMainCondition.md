# Condition

According to the template engine you use, you can type in the docx document, a script managed by the template engine. The only requirement is that you must use Mergefield to set the script and not type directly the script in the docx to avoid problems because MS Word encode the typped content.

 - [#if(](http://velocity.apache.org/engine/releases/velocity-1.7/user-guide.html#Conditionals) for [Velocity](http://velocity.apache.org/).
 - [[#if](http://freemarker.sourceforge.net/docs/ref_directive_if.html) for [Freemarker](http://freemarker.sourceforge.net/).

 
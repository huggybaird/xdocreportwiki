# One-sentence summary of this page.

# Apache POI - HWPF

[Apache POI - HWPF](http://poi.apache.org/hwpf/index.html) is Java API to Handle Microsoft Word Files.

# XWPF converter

If you wish convert DOCX :

 - to **XHTML** please read [here](XWPFConverterXHTML).
 - to **PDF (with iText)** please read [here](XWPFConverterPDFViaIText).
# Text styling

Since **[XDocReport 0.9.3](XDocReport093)** provides **text styling** feature. You can see demo at http://xdocreport.opensagres.cloudbees.net/textStyling.jsp?reportId=docx

## What is text styling?

XDocReport can replace a mergefield from docx report:

* by a value coming from Java context: 

```java
context.put("comments", "Text coming from Java context.");
```

* to generate this report : 

![](screenshots/DocxTextStylingExplanation2.png)

Since **[XDocReport 0.9.3](XDocReport093)**, XDocReport provides the capability to style the text of the Java context with some syntax (HTML, Wiki, etc). For instance, you can set text as italic and bold with HTML syntax like this :

```java
context.put("comments", "<p><i>Text</i> coming from <b>Java context</b>.</p>");
```

and generate this report : 

![](screenshots/DocxTextStylingExplanation3.png).

## Text styling syntax

Text Styling uses a syntax to style the text from the Java context. XDocReport provides several syntax like :

 - [[HTML syntax|DocxReportingJavaMainHTMLTextStyling]],
 - [[Wiki Text Styling|DocxReportingJavaMainWikiTextStyling]] like Mediawiki, Google wiki,
 - [[Markdown Text Styling|DocxReportingJavaMainMarkdownTextStyling]].

But it's possible to implement your own syntax if you wish: you can look [how Markdown syntax has been integrated](https://github.com/tiry/xdocreport-extensions).
A.16 - <Macro-xxxxxx> 
<<$project.Name>>


Índice

(Actualizar con cada cambio que se realice: clic sobre el índice, clic botón derecho, opción Actualizar Campos y luego Actualizar Toda la Tabla) 

1.	HISTORIAL DE CAMBIOS	2
2.	PROPÓSITO Y ALCANCE	3
3.	DATOS DE LA PETICIÓN	3
4.	OBJETIVOS TÉCNICOS	4
5.	EXCLUSIONES Y SUPUESTOS	4
6.	FUNCIONALIDADES	5
PRE-REQUISITOS PARA EL DESARROLLO	5
Performance	5
CONFIGURACIÓN REQUERIDA DEL AMBIENTE	5
CONDICIONES PARTICULARES DE PRUEBA A CUBRIR	5
7.	PROPUESTA DE DESARROLLO	5
ESPECIFICACIÓN TÉCNICA DEL REQUERIMIENTO	5
8.	DISEÑO ARQUITECTÓNICO	6
ARQUITECTURA - DIAGRAMAS ARQUITECTÓNICO DE CONEXIÓN NECESARIA A OTROS SISTEMAS/COMPONENTES (CS)	6
ARQUITECTURA - DIAGRAMA GENERAL DE COMPONENTES	6
DETALLE DE NUEVAS INTERFACES PROGRAMÁTICAS USADAS POR LA APLICACIÓN	7
DETALLE DE NUEVAS INTERFACES PROGRAMÁTICAS BRINDADA POR LA APLICACIÓN	7
DETALLE DE NUEVAS ORQUESTACIONES NECESARIAS	7
9.	SERVICIO	9
ARQUITECTURA - DIAGRAMA DE SECUENCIA BÁSICO	12
PROCESO DE EJECUCIÓN DE  WEB SERVICE	13
EVALUACIÓN Y TRANSFORMACIÓN DE DATOS	14
PAGINACIÓN	14
TRAMAS	19
WSDL	19
10.	COMPROMISOS INTERGRUPALES 	24
11.	DOCUMENTACIÓN ADICIONAL 	24
12.	PARAMETRIZACIÓN ADICIONAL (VÍA PROPIEDADES U OTRO)	24
13.	GLOSARIO 	24
14.	CATÁLOGO DE ERRORES 	25
15.	VALIDACIÓN ARQUITECTÓNICA POSTERIOR AL DESARROLLO	25


1.	Historial de cambios 

Versión	Autor	Fecha	Descripción
1.0	Rubén Vinent	04/03/2015	Modificación del servicio, se agregan parámetros para el control de centralización

2.0	Paola Ramírez	12/04/2016	Se agrega parámetros para validación de datos y cliente restringido
3.0	Guillermo Villanueva	18/04/2016	Agregado del WSDL y modificación parámetro de entrada i_s_direccion a varchar(3)
4.0	Guillermo Villanueva	03/05/2016	Agregado de parámetros i_cambio_estado_norm
5.0	Guillermo Villanueva	13/05/2016	modificación del WSDL
6.0	Guillermo Villanueva	13/05/2016	Aclaración sobre el manejo de error en la ejecución del sp sp_cl_estados_normalizacion_fe

2.	Propósito y Alcance 
El propósito del documento ‘A16 – Determinación de Impacto’ es detallar ….
Nota: Completar con detalle las especificaciones necesarias para el desarrollo del requerimiento solicitado.

3.	Datos de la petición

Identificación de la Petición	MACRO

Solicitante	
Gerencia del Solicitante	Individuos
Fecha Solicitud	
Tipo	 Necesidad de Negocio
ID Cambio / Ruta	 MACRO
Título del Cambio	ABM_Modificaciones_Direcciones_Físicas 
Sistema / Módulo	

Delegado del PA  
(si aplica)	

Responsable  	

Fecha límite de fin de desarrollo
(si existiera)	N/A
Fecha límite de fin de implementación
(si existiera)	N/A

 
4.	Objetivos Técnicos
<Se debe proveer una descripción sintética de los objetivos que se quieren alcanzar con el desarrollo solicitado; se debe registrar al menos un objetivo, todas las columnas son de carácter requerido>
<Algunos ejemplos pueden ser:
•	Cumplir estándares definidos
•	No ser intrusivo o causar impacto significativo en módulos críticos
•	Se pueden explotar los requerimientos no funcionales que se hayan identificado en el A10
•	Cumplimiento de normativas, es una caso específicamente técnico
•	Previsiones de reusabilidad
•	Indicar la reusabilidad de componentes ya existentes, si se los identifica
•	Referenciar a documentos
•	Previsiones de penalización en rendimiento de un componente sobre otro (ejemplo Servidor Central / Cliente)>


ID	Tipo de Objetivo
(Funcional/ No Funcional)	Descripción 	Importancia (Indispensable/  Importante/  
Deseable)
1	Funcional	Todas las secciones son obligatorias salvo se indique lo contrario	Importante
2	Funcional/No		
3			

5.	Exclusiones y supuestos 

ID	Tipo  (Exclusión/ Supuesto)	Descripción 	Referente validador  
1	Supuesto		
2	Exclusiones		
3			

 
6.	Funcionalidades

Este servicio debe permitir las operación de alta, baja, eliminación y consulta de las direcciones físicas de un cliente MIS
Se  puede consultar n direcciones o la dirección puntual de un cliente
	Pre-requisitos para el desarrollo
(*) Si corresponde, detallar pre requisitos al desarrollo o recuperarlo del A10.

		Performance

	Configuración requerida del ambiente
(*) Si corresponde, detallar pre requisitos al desarrollo o recuperarlo del A10.

	Condiciones particulares de Prueba a Cubrir 
(*) Si corresponde, detallar 

7.	Propuesta de Desarrollo

<En este apartado, en caso de nuevos desarrollos, se debe realizar una descripción de la funcionalidad  y de los procesos involucrados en dicho requerimiento.>
	Especificación técnica del requerimiento

 Marcar con una X el dato requerido ó S /N según indicación.

	Tipo Aplicación a Integrar	
1	Interna 	X
2	Externa (*)	
4	Funciona 7x24 (S/N)	N
5	Requiere Alta Disponibilidad - HA S/N)	N

(*) Externa si está fuera del banco.

	Componentes	Nuevo	Cambio
1	Conector		
2	Web Service / Servicio	X	
3	SP Virtual		
4	Orquestador		
 
8.	Diseño Arquitectónico 
	Arquitectura - Diagramas Arquitectónico de conexión necesaria a otros sistemas/componentes (CS)

< Este apartado lo completa Arquitectura, en caso que corresponda. Visualizar el diagrama con las interfaces de la aplicación como componente (caja negra). Se incluyen tanto las interfaces que proveen servicios potencialmente utilizables desde otras aplicaciones, así como las interfaces que le permiten a la aplicación interactuar con otros módulos/ componentes/ aplicaciones/ servicios que deben existir para el correcto funcionamiento. En estos últimos casos, se deben representar a estos componentes colaboradores en el gráfico. Se sugiere utilizar el diagrama de componentes de UML, con anotaciones para indicar tipo de conexión. Adaptar según corresponda, agregando, eliminando o modificando el diagrama>

 
	Arquitectura - Diagrama General de Componentes 
< Este apartado lo completa Arquitectura, en caso que corresponda >


 

	Detalle de nuevas interfaces programáticas usadas por la aplicación 

Interface / servicio	Aplicación / Módulo que la brinda	Particularidades de su uso
		
		
		
		

	Detalle de nuevas interfaces programáticas brindada por la aplicación 
<Identificar las interfaces a ser accedidas por otros componentes de otras aplicaciones o módulo. Es  posible utilizar el cuadro para agregar una cobertura total de las prestaciones brindadas por la aplicación, los casos de uso o las funcionalidades dónde intervienen actores humanos.>
Interface	
Descripción	
Operaciones/ Servicios	Nombre	Invocación 
(nombre y parámetros E/S)	Descripción
		
		
		

Protocolo de Invocación	<Indicar el orden genérico de invocación de las operaciones, en caso de ser relevantes. Por ejemplo: abrirsesión; (Read| Write)*; cierresesión.>
Protocolo Físico	<Identificar los detalles físicos para la correcta invocaron, obtención y lectura de resultados. Por ejemplo; formatos, tecnología de invocación, etc.>
Notas	


	Detalle de nuevas orquestaciones necesarias 
<Identificar las orquestaciones necesarias del módulo. Es  posible utilizar el cuadro para agregar una cobertura total de las orquestaciones brindadas por interfaz, por ejemplo.>
Orquestación	
Descripción	
Orquestaciones / Transformaciones de Datos	Nombre	Descripción
	
	
	

Notas	
 
9.	Servicio



Nombre del Servicio	CLABMDireccionesFisicas
 
Consume	
SP virtual	
SP de BD	X

Respuesta	
Un registro	
Lista de N registros	X
N Listas	
Variables de output	X
Msj ISO 8583	

Paginación	
Página (S/N)	N
Cantidad de registros	

Cliente / Consumidor	COBIS
Usuario de conexión	
Expone	
1	WSDL (S/N)	S
	•	Estándar ó Customizado (E/C)	E
	•	WS-Security (S/N)	N
	o	Perfil UserNameToken	
	o	Otro Perfil (¿cuál?)	
2	Requiere Password encriptada (S/N)	N
3	Relación de confianza    (S/N)           	N



 (**) Caracteres para identificar el módulo:

 
Clientes	CL	Paquetes	PA
Ahorros 	AH	Banca Virtual	BV
Corrientes 	CC	ATM	TM
Cartera	CA	ATC - Tarj. Crédito	TC
Plazo Fijo	PF	Firmas	FI
Crédito	CR	Concentrador	CO
Riesgo	RI	Trámites	TR
Garantía 	GA	Jubilaciones 	JU
Recaudaciones	RE	Plan sueldo	PS
Admin	AD		
 

(**) Si la aplicación no es Cobis, los máximo cuatro primeros caracteres deben hacer referencia al nombre de la aplicación.


Nombre SP Lógico *	(sp_ <3 caracteres del proyecto o módulo cobis + nombre el WS>) Máximo 30 caracteres
Descripción	
Transacción Cobis	
Código Procedure	
Producto Cobis	
Base de datos	
Moneda	
Nemónico	<6 caracteres>

Si no se ejecuta un SP Cobis, requiere código de transacción Cobis:

Nombre SP	<sp_aplicacion_externa)
Transacción Cobis	



Input
parámetro	tipo	Req.	Descripción
i_c_operacion            	char(1)	S	I – Alta
U – Modificación
D – Eliminación
Q – Consulta
i_c_opcion               	tinyint	S	1 - Alta
12 - Consulta
i_c_cliente              	int	S	Ente MIS
i_d_descripcion       	Varchar(64)	
S	Descripción de la calle
i_n_calle            	smallint	N	Número de la calle
i_d_piso              	varchar(2)  	N	Piso
i_d_depto             	varchar(3)  	N	Departamento
i_c_postal            	varchar(10)	S	Código Postal
i_c_ciudad            	smallint	N	Código de la ciudad
i_d_localidad         	varchar(64)	N	Descripción de la localidad
i_c_provincia         	smallint	S	Código de la provincia
i_c_parroquia         	smallint	S	Código de la parroquia
i_c_pais              	smallint	S	Código del país
i_d_tipo              	varchar(10)	N	Para la opción Q es opcional
i_c_oficina           	smallint	N	Código de la oficina
i_c_modulo_ingreso     	varchar(10)	N	Solo opción U
i_s_direccion	Varchar(3)	N	Secuencial de la dirección
Requerido para opción U – D
Opcional para la opción Q
i_c_orig_nocontac  	Varchar(10)	N	Origen de no contactar
i_m_principal	Char(1)	N	Marca principal
i_f_verificacion	Varchar(10)	N	Fecha de verificacion DD/MM/AAAA
i_u_verificacion	Varchar(30)	N	Usuario Login
i_m_val_cli	Char(1)	N	Valida cliente S/N
i_m_verificar_restringidos	Char(1)	N	Verifica restringidos S/N
i_m_valida_sin_telefono	Char(1)	N	Valida sin teléfono S/N
i_m_cambio_m_laboral	Char(1)	N	Marca cambio domicilio laboral S/N
i_m_verificado	Char(1)	N	Marca de verificado S/N
i_s_direccion_normaliza	int	N	Secuencial de normalización de dirección
i_e_normalizacion	Varchar(3)	N	Estado de normalización
i_m_motivo_merlin	Varchar(3)	N	Motivo de no normalización
i_u_normalizacion	Varchar(8)	N	Usuario de normalización
i_f_normalizacion	Varchar(10)	N	Fecha de normalización
El formato de fecha de DD/MM/YYYY
i_m_laboral	Char(1)	N	Marca de domicilio laboral S/N
i_m_permiso_duplicados	Char(1)	N	Marca de permiso duplicados S/N
i_m_eventual	int	N	Marca de cliente eventual
0 – habitual
1 – eventual prospecto
2 – eventual cambio moneda
i_c_postal_nuevo	Varchar(8)	N	Código postal argentino.
i_m_cambio_estado_norm	Char(1)	S	Marca de estado de normalización
S: Si se modificaron los campos normalizables
N: Si no se modificaron


Output - Operación I– Opción 1 - Alta de dirección física para un ente MIS y Operación U - Modificación de dirección física para un ente MIS

Output
parámetro	tipo	Descripción
o_s_direccion         	tinyint	Secuencial de dirección


Operación Q – Opción 12 - Consulta de direcciones físicas para un ente MIS

Output
parámetro	Tipo	Descripción
ArrayDirFisicas	OArrayDirFisicas	Lista de direcciones físicas

OArrayDirFisicas
parámetro	tipo	Descripción
o_s_direccion	tinyint	Secuencial de la dirección
o_c_tipo_direccion	Varchar(10)	Tipo de dirección
o_d_calle	Varchar(64)	Calle
o_n_calle	smallint	Numero
o_d_piso	char(2)    	Piso
o_d_depto	char(3)    	Depto
o_c_postal	varchar(4	Código Postal
o_c_ciudad	smallint	Código de la ciudad
o_d_ciudad	Varchar(64)	Descripción de la ciudad
o_c_provincia	tinyint	Código de la provincia
o_d_provincia	Varchar(64)	Descripción de la provincia
o_c_pais	smallint	Código del país
o_d_pais	Varchar(64)	Descripción del país
o_c_orig_nocontac  	Varchar(10)	
o_m_principal	Char(1)	
o_f_verificacion	Varchar(10)	
o_u_verificacion	Varchar(8)	

Service Error
parámetro	tipo	Descripción
Code	number	- 0 – OK
- Código de error
Message	char(1)	- Null si code = 0
- Mensaje de error

(**) Para fechas se recomienda tipo de dato string, en la descripción se debe informar el formato de fecha tanto en el input como en el output. Para el tipo de dato Money y Porcentaje se debe informar cantidad de decimales y si requiere redondear.

(***) Indicar qué campos son requeridos para la funcionalidad. Informar en el proceso de ejecución, si el servicio debe validar que el parámetro sea distinto de null o vacío.
	Arquitectura - Diagrama de Secuencia Básico

< Este apartado lo completa Arquitectura, en caso que corresponda >

Durante el proceso de ejecución del Web Service, el servicio puede ejecutar uno o más SP’s o invocar uno o más WS. Puede haber o no transformaciones de datos. La secuencia de ejecución es importante.

<Adaptar según corresponda, agregando, eliminando o modificando el diagrama>


 


	Proceso de ejecución de  Web Service


Valida parámetros requeridos: Si se requiere validación indicar código y mensaje de error y si termina la ejecución o continua.

Campo	Código de Error	Mensaje de Error	Descripción de validación
i_c_modulo_ingreso     	122	Debe ingresar un dato en el campo i_c_modulo_ingreso para la opción U 	Si i_c_operacion es igual a “U” valida. , si i_c_modulo_ingreso está vacío o es null devuelve mensaje de error.
i_s_direccion	123	Debe ingresar un dato para el campo i_s_direccion para las opciones U y D 
Opcional para la opción Q	Si i_c_operacion es igual a “U” o igual a “D” valida.
Si i_s_direccion, está vacío o es null devuelve mensaje de error.
i_c_operacion	101	El valor del campo i_c_operacion debe ser "I", "U","D","Q"	Si i_c_operacion es distinto de "I" o "U" o “D” o “Q”,  devuelve mensaje de error.
i_c_opcion               	102	El valor del campo i_c_opcion debe ser “1”, “12”	Si el campo i_c_opcion                es distinto de “1” o “12” valida,  devuelve mensaje de error.

	
	Evaluación y Transformación de Datos 
Si se requiere una evaluación de datos o su transformación, indicar tipo.

Evaluación	Booleana	
String vs. String	
Hash 	
CRC32	

Transformación	String / Integer	
EBCDIC / ASCII	
Encode64 / Decode64	
Base64Binary	
BLOB (imagen)	
Otra	

	Paginación 
Si se requiere una paginación, indicar registros por ciclo y máximos.

Pagína resultado	Cantidad de registros por ciclo (página)	
Máximo de páginas (si hubiera , o EOF)	
Máximo de buffer a enviar (si fuera calculable, kb)	


El servicio puede ejecutar uno o más SP’s o invocar uno o más WS. La secuencia de ejecución es importante.

Operación I – Opción 1 - Alta de dirección física para un ente MIS

Servidor Central
cobis.. sp_direccion
Parámetro (SP / WS)	Parámetro input	Tipo Dato	Descripción
@t_trn                  	109	smallint	Numero de transacción
@i_formato_fecha	103	tinyint	Formato fecha dd/mm/aaaa
@i_operacion            	i_c_operacion            	char(1)     	Código de la operación
@i_opcion               	i_c_opcion               	tinyint	Numero de opción
@i_quien_llama	'F'	char(1)     	
@i_di_ente              	i_c_cliente              	int	Cliente MIS
@i_di_descripcion       	i_d_descripcion       	Varchar(64)	Nombre de la calle
@i_di_numero            	i_n_calle            	smallint	Número de la calle
@i_di_piso              	i_d_piso              	varchar(2)  	Piso
@i_di_depto             	i_d_depto             	varchar(3)  	Depto
@i_di_postal	i_c_postal            	varchar(10)	Codigo Postal
@i_di_ciudad	i_c_ciudad            	smallint	Codigo de ciudad
@i_di_localidad         	i_d_localidad         	varchar(64)	Descripcion de la localidad
@i_di_provincia         	i_c_provincia         	smallint	Codigo de provincia
@i_di_parroquia         	i_c_parroquia         	smallint	Codigo de parroquia
@i_di_pais              	i_c_pais              	smallint	Codigo de país
@i_di_tipo              	i_d_tipo              	varchar(10)	Tipo
@i_di_oficina           	i_c_oficina           	smallint	Oficina
@i_di_orig_nocontac  	i_c_orig_nocontac  		
@i_di_marca_principal	i_m_principal		
@i_di_fecha_verific	i_f_verificacion		Transformar el formato de fecha de DD/MM/YYYY a MM/DD/YYYY
@i_di_usuario_verific	i_u_verificacion		
@i_val_cli	i_m_val_cli		
@i_verificar_restringidos	i_m_verificar_restringidos		
@i_m_valida_sin_telefono	i_m_valida_sin_telefono		
@i_m_cambio_m_laboral	i_m_cambio_m_laboral		
@i_di_verificado	i_m_verificado		
@i_di_s_direccion_normaliza	i_s_direccion_normaliza		
@i_di_e_merlin	i_e_normalizacion		
@i_di_m_motivo_merlin	i_m_motivo_merlin		
@i_di_u_normalizacion	i_u_normalizacion		
@i_di_f_normalizacion	i_f_normalizacion		Transformar el formato de fecha de DD/MM/YYYY a MM/DD/YYYY
@i_di_m_laboral	i_m_laboral		
@i_permiso_duplicados	i_m_permiso_duplicados		
@i_en_eventual	i_m_eventual		
@i_di_postal_nuevo	i_c_postal_nuevo		

Respuesta
Parámetro SP / WS
proveedor	Parámetro output
CTS	Descripción
@o_di_direccion         	o_s_direccion         	Secuencial de la dirección

Operación U – Modificación de dirección física para un ente MIS

Servidor Central
cobis.. sp_direccion
Parámetro (SP / WS)	Parámetro input	Tipo Dato	Descripción
@t_trn                  	109	smallint	Numero de transacción
@i_operacion            	i_operacion            	char(1)     	Código de la operación
@i_quien_llama	'F'	char(1)     	
@i_di_ente              	i_c_cliente              	int	Cliente MIS
@i_di_direccion         	i_s_direccion	tinyint	Secuencial de dirección
@i_di_descripcion       	i_d_descripcion       	Varchar(64)	Nombre de la calle
@i_di_numero            	i_n_calle            	smallint	Número de la calle
@i_di_piso              	i_d_piso              	varchar(2)  	Piso
@i_di_depto             	i_d_depto             	varchar(3)  	Depto.
@i_di_postal	i_c_postal            	varchar(10)	Código Postal
@i_di_ciudad	i_c_ciudad            	smallint	Código de ciudad
@i_di_localidad         	i_d_localidad         	varchar(64)	Descripción de la localidad
@i_di_provincia         	i_c_provincia         	smallint	Código de provincia
@i_di_parroquia         	i_c_parroquia         	smallint	Código de parroquia
@i_di_pais              	i_c_pais              	smallint	Código de país
@i_di_tipo              	i_d_tipo              	varchar(10)	Tipo
@i_di_oficina           	i_c_oficina           	smallint	Oficina
@i_c_modulo_ingreso     	i_c_modulo_ingreso     	varchar(10)	Código de módulo de ingreso
@i_di_orig_nocontac  	i_c_orig_nocontac  		
@i_di_marca_principal	i_m_principal		
@i_di_fecha_verific	i_f_verificacion		Transformar el formato de fecha de DD/MM/YYYY a MM/DD/YYYY
@i_di_usuario_verific	i_u_verificacion		
@i_val_cli	i_m_val_cli		
@i_verificar_restringidos	i_m_verificar_restringidos		
@i_m_valida_sin_telefono	i_m_valida_sin_telefono		
@i_m_cambio_m_laboral	i_m_cambio_m_laboral		
@i_di_verificado	i_m_verificado		
@i_di_s_direccion_normaliza	i_s_direccion_normaliza		
@i_di_e_merlin	i_e_normalizacion		
@i_di_m_motivo_merlin	i_m_motivo_merlin		
@i_di_u_normalizacion	i_u_normalizacion		
@i_di_f_normalizacion	i_f_normalizacion		Transformar el formato de fecha de DD/MM/YYYY a MM/DD/YYYY
@i_di_m_laboral	i_m_laboral		
@i_permiso_duplicados	i_m_permiso_duplicados		
@i_en_eventual	i_m_eventual		
@i_di_postal_nuevo	i_c_postal_nuevo		

Si la actualización del WS no da error y el paramero i_m_cambio_estado_norm = ‘S’, se debe ejecutar el sp  cobis..sp_cl_estados_normalizacion_fe, 

Servidor Central
cobis..sp_cl_estados_normalizacion_fe
Parámetro (SP / WS)	Parámetro input	Tipo Dato	Descripción
@t_trn	1736	smallint	Numero de transacción
@i_operacion	U	char(1)     	Código de la operación
@i_opcion	2	Tinyint	
@i_cantidad_registros	40	Smallint	
@i_formato_fecha	103	Tinyint	
@i_quien_llama	‘F’	Char(1)	F: Front end
@i_n_ente	i_c_cliente              	Int	
@i_n_direccion	i_s_direccion	Int	
@i_e_normalizacion	i_e_normalizacion	Varchar(10)	
@i_u_usuario 	i_u_normalizacion	Varchar(30)	
@i_f_fecha	i_f_normalizacion	Varchar(10)	Transformar el formato de fecha de DD/MM/YYYY a MM/DD/YYYY

Si la ejecución del sp no fue correcta el error será informado en el Service Error


. Operación D – Eliminación de una dirección física

Servidor Central
cobis.. sp_direccion
Parámetro (SP / WS)	Parámetro input	Tipo Dato	Descripción
@t_trn                  	109	smallint	Numero de transacción
@i_operacion            	i_operacion            	char(1)     	Código de la operación
@i_quien_llama	'F'	char(1)     	
@i_di_ente              	i_c_cliente              	int	Cliente MIS
@i_di_direccion         	i_s_direccion	tinyint	Secuencial de dirección
@i_verificar_restringidos	i_m_verificar_restringidos		

. Operación Q – Opción 12 - Consulta de direcciones físicas para un ente MIS

Servidor Central
cobis.. sp_direccion
Parámetro (SP / WS)	Parámetro input	Tipo Dato	Descripción
@t_trn                  	109	smallint	Numero de transacción
@i_operacion            	i_operacion            	char(1)     	Código de la operación
@i_opcion               	i_c_opcion               	tinyint	Numero de Opción 
@i_quien_llama	‘F'	char(1)     	
@i_di_ente              	i_c_cliente              	int	Cliente MIS
@i_di_tipo              	i_d_tipo              	varchar(10)	Tipo
@i_di_direccion         	i_s_direccion	tinyint	Secuencial de dirección
@i_verificar_restringidos	i_m_verificar_restringidos		

Esta opción permite consulta enviando el secuencial y obtener un solo registro de la dirección en particular,  si se omite (ya que no es un campo requerido en la consulta) el secuencial, traerá una lista de las direcciones pertenecientes al ente

OArrayDirFisicas
Parámetro SP / WS
proveedor	Parámetro output
CTS	Descripción
#SEC	o_s_direccion	Secuencial de la dirección
TDIR	o_c_tipo_direccion	Tipo de dirección
CALLE	o_d_calle	Calle
NUMERO	o_n_calle	Numero
PISO	o_d_piso	Piso
DPTO	o_d_depto	Depto.
C_POSTAL	o_c_postal	Código Postal
#CIUDAD	o_c_ciudad	Código de la ciudad
CIUDAD	o_d_ciudad	Descripción de la ciudad
#PROVINCIA	o_c_provincia	Código de la provincia
PROVINCIA	o_d_provincia	Descripción de la provincia
#PAIS	o_c_pais	Código del país
PAIS	o_d_pais	Descripción del país
orig_nocontac  	o_c_orig_nocontac  	
marca_principal	o_m_principal	
fecha_verif	o_f_verificacion	
usuario_verific	o_u_verificacion	


Service Error
parámetro	tipo	Descripción
Code	number	- 0 – OK
- Código de error
Message	char(1)	- Null si code = 0
- Mensaje de error
Type		


	Tramas 
<Tramas de ejemplo si las hubiera>
	WSDL 
CLABMDireccionesFisicasService.wsdl
<?xml version="1.0" encoding="UTF-8"?>
<definitions name="CLABMDireccionesFisicasService" targetNamespace="http://webservices.cts.ast/" xmlns="http://schemas.xmlsoap.org/wsdl/" xmlns:wsp="http://www.w3.org/ns/ws-policy" xmlns:wsu="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:tns="http://webservices.cts.ast/" xmlns:soap="http://schemas.xmlsoap.org/wsdl/soap/">
  <types>
    <xsd:schema>
      <xsd:import namespace="http://webservices.cts.ast/" schemaLocation="CLABMDireccionesFisicasService_schema1.xsd"/>
    </xsd:schema>
  </types>
  <message name="executeResponse">
    <part name="parameters" element="tns:executeResponse">
    </part>
  </message>
  <message name="execute">
    <part name="parameters" element="tns:execute">
    </part>
  </message>
  <portType name="CLABMDireccionesFisicas">
    <operation name="execute">
      <input message="tns:execute">
    </input>
      <output message="tns:executeResponse">
    </output>
    </operation>
  </portType>
  <binding name="CLABMDireccionesFisicasPortBinding" type="tns:CLABMDireccionesFisicas">
    <soap:binding style="document" transport="http://schemas.xmlsoap.org/soap/http"/>
    <wsp:PolicyReference URI="#8e36b6e6-66a5-4efc-9545-045affadb37c"/>
    <operation name="execute">
      <soap:operation soapAction=""/>
      <input>
        <soap:body use="literal"/>
        <wsp:PolicyReference URI="#6c8d25dd-ede1-4ec9-9838-099b0f759ee8"/>
      </input>
      <output>
        <soap:body use="literal"/>
      </output>
    </operation>
  </binding>
  <service name="CLABMDireccionesFisicasService">
    <port name="CLABMDireccionesFisicasPort" binding="tns:CLABMDireccionesFisicasPortBinding">
      <soap:address location="http://wks0109.accusysargbsas.local:9080/AST-WS-CTS-CRM-CL_ABM_DIRECCIONES_FISICAS/CLABMDireccionesFisicasService"/>
    </port>
  </service>
  <wsp:Policy wsu:Id="8e36b6e6-66a5-4efc-9545-045affadb37c">
    <wsp:ExactlyOne>
      <wsp:All>
        <addressing:Addressing xmlns:addressing="http://www.w3.org/2007/05/addressing/metadata">          <wsp:Policy>
            <wsp:ExactlyOne>
              <wsp:All>
              </wsp:All>
            </wsp:ExactlyOne>
          </wsp:Policy>
</addressing:Addressing>
      </wsp:All>
      <wsp:All>
        <addressing:Addressing xmlns:addressing="http://www.w3.org/2007/05/addressing/metadata">          <wsp:Policy>
            <wsp:ExactlyOne>
              <wsp:All>
                <addressing:AnonymousResponses/>
              </wsp:All>
            </wsp:ExactlyOne>
          </wsp:Policy>
</addressing:Addressing>
      </wsp:All>
      <wsp:All>
        <addressing:Addressing xmlns:addressing="http://www.w3.org/2007/05/addressing/metadata">          <wsp:Policy>
            <wsp:ExactlyOne>
              <wsp:All>
                <addressing:NonAnonymousResponses/>
              </wsp:All>
            </wsp:ExactlyOne>
          </wsp:Policy>
</addressing:Addressing>
      </wsp:All>
      <wsp:All>
      </wsp:All>
    </wsp:ExactlyOne>
  </wsp:Policy>
  <wsp:Policy wsu:Id="6c8d25dd-ede1-4ec9-9838-099b0f759ee8">
    <sp:SupportingTokens xmlns:sp="http://docs.oasis-open.org/ws-sx/ws-securitypolicy/200702">      <wsp:Policy>
        <sp:UsernameToken sp:IncludeToken="http://docs.oasis-open.org/ws-sx/ws-securitypolicy/200702/IncludeToken/AlwaysToRecipient">          <wsp:Policy>
            <sp:WssUsernameToken10/>
          </wsp:Policy>
</sp:UsernameToken>
      </wsp:Policy>
</sp:SupportingTokens>
  </wsp:Policy>
</definitions>

CLABMDireccionesFisicasService_schema1.xsd
<?xml version="1.0" encoding="UTF-8"?><xs:schema xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns:tns="http://webservices.cts.ast/" targetNamespace="http://webservices.cts.ast/" version="1.0">

  <xs:element name="cLABMDireccionesFisicasFil" type="tns:cLABMDireccionesFisicasFil"/>

  <xs:element name="cLABMDireccionesFisicasQRet" type="tns:cLABMDireccionesFisicasQRet"/>

  <xs:element name="cLABMDireccionesFisicasRes" type="tns:cLABMDireccionesFisicasRes"/>

  <xs:element name="cLABMDireccionesFisicasRet" type="tns:cLABMDireccionesFisicasRet"/>

  <xs:element name="execute" type="tns:execute"/>

  <xs:element name="executeResponse" type="tns:executeResponse"/>

  <xs:element name="oArrayDirFisicas" type="tns:oArrayDirFisicas"/>

  <xs:complexType name="execute">
    <xs:sequence>
      <xs:element minOccurs="0" name="requestConnection" type="tns:requestConnection"/>
      <xs:element minOccurs="0" name="filtro" type="tns:cLABMDireccionesFisicasFil"/>
    </xs:sequence>
  </xs:complexType>

  <xs:complexType name="requestConnection">
    <xs:sequence>
      <xs:element minOccurs="0" name="applicationID" type="xs:string"/>
      <xs:element minOccurs="0" name="password" type="xs:string"/>
      <xs:element minOccurs="0" name="sessionID" type="xs:string"/>
      <xs:element minOccurs="0" name="user" type="xs:string"/>
    </xs:sequence>
  </xs:complexType>

  <xs:complexType name="cLABMDireccionesFisicasFil">
    <xs:sequence>
      <xs:element name="i_c_operacion" nillable="true" type="xs:string"/>
      <xs:element name="i_c_opcion" nillable="true" type="xs:int"/>
      <xs:element name="i_c_cliente" nillable="true" type="xs:int"/>
      <xs:element name="i_d_descripcion" nillable="true" type="xs:string"/>
      <xs:element minOccurs="0" name="i_n_calle" nillable="true" type="xs:int"/>
      <xs:element minOccurs="0" name="i_d_piso" nillable="true" type="xs:string"/>
      <xs:element minOccurs="0" name="i_d_depto" nillable="true" type="xs:string"/>
      <xs:element name="i_c_postal" nillable="true" type="xs:string"/>
      <xs:element minOccurs="0" name="i_c_ciudad" nillable="true" type="xs:int"/>
      <xs:element minOccurs="0" name="i_d_localidad" nillable="true" type="xs:string"/>
      <xs:element name="i_c_provincia" nillable="true" type="xs:int"/>
      <xs:element name="i_c_parroquia" nillable="true" type="xs:int"/>
      <xs:element name="i_c_pais" nillable="true" type="xs:int"/>
      <xs:element minOccurs="0" name="i_d_tipo" nillable="true" type="xs:string"/>
      <xs:element minOccurs="0" name="i_c_oficina" nillable="true" type="xs:int"/>
      <xs:element minOccurs="0" name="i_c_modulo_ingreso" nillable="true" type="xs:string"/>
      <xs:element minOccurs="0" name="i_s_direccion" nillable="true" type="xs:string"/>
      <xs:element minOccurs="0" name="i_c_orig_nocontac" nillable="true" type="xs:string"/>
      <xs:element minOccurs="0" name="i_m_principal" nillable="true" type="xs:string"/>
      <xs:element minOccurs="0" name="i_f_verificacion" nillable="true" type="xs:string"/>
      <xs:element minOccurs="0" name="i_u_verificacion" nillable="true" type="xs:string"/>
      <xs:element minOccurs="0" name="i_m_val_cli" nillable="true" type="xs:string"/>
      <xs:element minOccurs="0" name="i_m_verificar_restringidos" nillable="true" type="xs:string"/>
      <xs:element minOccurs="0" name="i_m_valida_sin_telefono" nillable="true" type="xs:string"/>
      <xs:element minOccurs="0" name="i_m_cambio_m_laboral" nillable="true" type="xs:string"/>
      <xs:element minOccurs="0" name="i_m_verificado" nillable="true" type="xs:string"/>
      <xs:element minOccurs="0" name="i_s_direccion_normaliza" nillable="true" type="xs:int"/>
      <xs:element minOccurs="0" name="i_e_normalizacion" nillable="true" type="xs:string"/>
      <xs:element minOccurs="0" name="i_m_motivo_merlin" nillable="true" type="xs:string"/>
      <xs:element minOccurs="0" name="i_u_normalizacion" nillable="true" type="xs:string"/>
      <xs:element minOccurs="0" name="i_f_normalizacion" nillable="true" type="xs:string"/>
      <xs:element minOccurs="0" name="i_m_laboral" nillable="true" type="xs:string"/>
      <xs:element minOccurs="0" name="i_m_permiso_duplicados" nillable="true" type="xs:string"/>
      <xs:element minOccurs="0" name="i_m_eventual" nillable="true" type="xs:int"/>
      <xs:element minOccurs="0" name="i_c_postal_nuevo" nillable="true" type="xs:string"/>
      <xs:element name="i_m_cambio_estado_norm" nillable="true" type="xs:string"/>
    </xs:sequence>
  </xs:complexType>

  <xs:complexType name="executeResponse">
    <xs:sequence>
      <xs:element minOccurs="0" name="return" type="tns:cLABMDireccionesFisicasRes"/>
    </xs:sequence>
  </xs:complexType>

  <xs:complexType name="cLABMDireccionesFisicasRes">
    <xs:sequence>
      <xs:element name="serviceError" nillable="true" type="tns:serviceError"/>
      <xs:element name="cLABMDireccionesFisicasRet" nillable="true" type="tns:cLABMDireccionesFisicasRet"/>
      <xs:element name="cLABMDireccionesFisicasQRet" nillable="true" type="tns:cLABMDireccionesFisicasQRet"/>
    </xs:sequence>
  </xs:complexType>

  <xs:complexType name="serviceError">
    <xs:sequence>
      <xs:element minOccurs="0" name="code" type="xs:long"/>
      <xs:element minOccurs="0" name="message" type="xs:string"/>
      <xs:element minOccurs="0" name="type" type="xs:string"/>
    </xs:sequence>
  </xs:complexType>

  <xs:complexType name="cLABMDireccionesFisicasRet">
    <xs:sequence>
      <xs:element name="o_s_direccion" nillable="true" type="xs:int"/>
    </xs:sequence>
  </xs:complexType>

  <xs:complexType name="cLABMDireccionesFisicasQRet">
    <xs:sequence>
      <xs:element minOccurs="0" name="arrayDirFisicas" nillable="true">
        <xs:complexType>
          <xs:sequence>
            <xs:element maxOccurs="unbounded" name="OArrayDirFisicas" nillable="true" type="tns:oArrayDirFisicas"/>
          </xs:sequence>
        </xs:complexType>
      </xs:element>
    </xs:sequence>
  </xs:complexType>

  <xs:complexType name="oArrayDirFisicas">
    <xs:sequence>
      <xs:element name="o_s_direccion" nillable="true" type="xs:int"/>
      <xs:element name="o_c_tipo_direccion" nillable="true" type="xs:string"/>
      <xs:element name="o_d_calle" nillable="true" type="xs:string"/>
      <xs:element name="o_n_calle" nillable="true" type="xs:int"/>
      <xs:element name="o_d_piso" nillable="true" type="xs:string"/>
      <xs:element name="o_d_depto" nillable="true" type="xs:string"/>
      <xs:element name="o_c_postal" nillable="true" type="xs:string"/>
      <xs:element name="o_c_ciudad" nillable="true" type="xs:int"/>
      <xs:element name="o_d_ciudad" nillable="true" type="xs:string"/>
      <xs:element name="o_c_provincia" nillable="true" type="xs:int"/>
      <xs:element name="o_d_provincia" nillable="true" type="xs:string"/>
      <xs:element name="o_c_pais" nillable="true" type="xs:int"/>
      <xs:element name="o_d_pais" nillable="true" type="xs:string"/>
      <xs:element name="o_c_orig_nocontac" nillable="true" type="xs:string"/>
      <xs:element name="o_m_principal" nillable="true" type="xs:string"/>
      <xs:element name="o_f_verificacion" nillable="true" type="xs:string"/>
      <xs:element name="o_u_verificacion" nillable="true" type="xs:string"/>
    </xs:sequence>
  </xs:complexType>
</xs:schema>








 
10.	Compromisos intergrupales  

Nota: Si se informan estos datos en el cronograma, no es necesario completar la sección.

ID 	Descripción Prerrequisito  	Sector / Proyecto / Proveedor  (responsables del prerrequisito)	Responsable  (para evaluar progreso de prerrequisito) 	Monitoreo y comunicación  (medios por los que se conoce el estado) 	Fecha 
límite  
					
					
11.	Documentación adicional  
Nota: Opcional. Solo si se contemplara.
  

ID	Descripción	Nombre de archivo	Referencia
			
			

12.	Parametrización adicional (vía propiedades u otro)  
Nota: Opcional. Solo si se contemplara.

Los ID de métodos publicados, como las rutas de los servicios, y otros similares, deben estar parametrizados en sus respectivas propiedades de módulo. No deben ser puestas como constantes dentro del código fuente. Lo mismo para las credencial “fija”.

ID	Descripción	Valor
		
		

13.	Glosario  
Nota: Opcional.

Término	Definición
IBM DataPower	IBM WebSphere DataPower Integration Appliance es un dispositivo (hardware) de red sin interrupciones que proporciona funciones comunes de direccionamiento, integración y transformación de mensajes. 
Ver http://www-03.ibm.com/software/products/es/datapower-xi52

CTS/CIS	Cobis Transaction Server / Cobis Integration Server
WAS	IBM Websphere Application Server
Umbral	Es una representación cuantitativa de una ruptura o discontinuidad más allá de la cual el fenómeno se comporta de manera radicalmente diferente. 
14.	Catálogo de errores  
Nota: Opcional.


Código 	Descripción
100	El valor del campo #### es requerido.
101	El valor del campo ### debe ser A, B ó C

15.	Validación Arquitectónica posterior al Desarrollo  
Fecha	Nombre /
Nro. ACT	Nombre del Responsable y Rol	Aprobado
Si/No/Obs.	Observaciones
13/01/2016	30419	Rubén Darío Vinent
Analista técnico funcional	Si	  WSDL ok
			No	  
			Si	  
			No	  
			Observado	  
			Observado	  
                     

Except for the license (MIT License instead of Apache License), we use the Maven Code Style and convention :

http://maven.apache.org/developers/conventions/code.html

If you are an eclipse Developper,please install first 
http://andrei.gmxhome.de/anyedit/

Then download and Import the maven codestyle [maven-eclipse-codestyle.xml](http://maven.apache.org/developers/maven-eclipse-codestyle.xml).

In the Preferences Menu Select :
Java -> Code Style -> Formatter -> Import

and point to the location of the xml file previously downloaded.
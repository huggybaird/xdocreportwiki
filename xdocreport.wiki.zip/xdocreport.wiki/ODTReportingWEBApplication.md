# ODT Reporting in WEB Application

See [DocxReportingWEBApplication](https://code.google.com/p/xdocreport/wiki/DocxReportingWEBApplication).
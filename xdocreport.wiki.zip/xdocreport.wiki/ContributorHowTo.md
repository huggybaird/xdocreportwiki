# This page explains how contributors should use xdocreport resources.

# Contributor's Guide

This guide is intended to help people willing to build xdocreport from source and/or who wants to contribute to xdocreport.
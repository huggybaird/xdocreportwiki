# Design Report

XDocReport give you the capability to create your report with MS Word or OppenOffice : 

 - [[Docx Design Report|Design Report Docx]] explains you how create your report by using MS Word docx.
 - [Design Report ODT](ODTDesignReport) explains you how create your report by using OppenOffice ODT.
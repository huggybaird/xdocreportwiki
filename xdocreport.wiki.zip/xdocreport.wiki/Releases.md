# Releases

Current release is **[XDocReport 1.0.4](XDocReport104)**.

[XDocReport source](http://code.google.com/p/xdocreport/source/checkout) are built with Maven 2.0. If you wish do that please read [here](HowBuildXDocReport).
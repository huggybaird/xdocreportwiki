# ODT Reporting

XDocReport give you the capability to generate report from ODT created with OpenOffice. Fields to replace are created by using Freemarker/Velocity syntax (ex : $name). If you want test ODT report quickly, you can read [Quick Start](ODTReportingQuickStart) section.

XDocReport with ODT can be used in several context : 

 - [Java Main](ODTReportingJavaMain) if you wish use XDocReport in **Java Main context**.
 - [WEB Application](ODTReportingWEBApplication) if you wish use XDocReport in **WEB Application context**.
 - [OSGi](ODTReportingOSGi) if you wish use XDocReport in **OSGi context**.
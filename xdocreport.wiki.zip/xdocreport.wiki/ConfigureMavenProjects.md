Once you have cloned the repo and imported the project,  your navigator view view should looks like this :


[We need to configure our project as "Maven project" to activate m2eclipse menu entry on project :

![](screenshots/ConfigureMavenProject2.png)(http://wiki.xdocreport.googlecode.com/git/screenshots/ConfigureMavenProject1.png))

Let's launch a full maven build (mvn install) :
This step may take a while since maven needs to download the required dependencies.

[At the end, you should be able to see a "BUILD SUCCESSFUL" in the console :

![](screenshots/ConfigureMavenProject4.png)(http://wiki.xdocreport.googlecode.com/git/screenshots/ConfigureMavenProject3.png))

Let's Import the maven modules :

[![](screenshots/ConfigureMavenProject6.png)(http://wiki.xdocreport.googlecode.com/git/screenshots/ConfigureMavenProject5.png))
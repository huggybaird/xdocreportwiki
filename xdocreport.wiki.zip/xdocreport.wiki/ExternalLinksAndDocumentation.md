## Eclipse IDE

  - http://www.eclipse.org/downloads/
  - m2eclipse : http://www.eclipse.org/m2e/
  - EGit : http://eclipse.org/egit/

## Maven

  - Maven : http://maven.apache.org/

## Git

  - Git Tutorial : http://www.vogella.de/articles/Git/article.html
  - Git with Eclipse (EGit) - Tutorial : http://www.vogella.de/articles/EGit/article.html
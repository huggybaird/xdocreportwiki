# Docx Reporting

XDocReport give you the capability to generate report from Docx created with MS Word. Fields to replace are created by using Freemarker/Velocity syntax (ex : $name). If you want test docx report quickly, you can read [Quick Start](DocxReportingQuickStart) section.

XDocReport with docx can be used in several context : 

 - [Java Main](DocxReportingJavaMain) if you wish to use XDocReport in **Java Main context**.
 - [WEB Application](DocxReportingWEBApplication) if you wish use XDocReport in **WEB Application context**.
 - [OSGi](DocxReportingOSGi) if you wish use XDocReport in **OSGi context**.
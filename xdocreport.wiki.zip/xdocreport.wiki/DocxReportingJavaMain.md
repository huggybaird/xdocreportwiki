# Docx Reporting in Java Main

This section explains step by step how to generate a report created with MS Word docx by using Velocity syntax to set fields to replace. You can download [docxandvelocity-*-sample.zip](http://code.google.com/p/xdocreport/downloads) which is the project explained in this section. 

We will create a basic docx document `DocxProjectWithVelocity.docx` : 

![](screenshots/DocxProjectWithVelocity.png)

The `$project.Name` is a merge field and project is Java model Project class which define `Project#getName()`. The field name start with _project_ because we will register the Java Model with `project` key in the context like this : 

```java
Project project = new Project("XDocReport");
context.put("project", project);
```

After report process we will generate the document _DocxProjectWithVelocity_Out.docx_ : 

![](screenshots/DocxProjectWithVelocity_Out.png)

Steps section are : 

 1. [Add XDocReport JARs](#add-xdocreport-jars) in your classpath project.
 1. [Create Java model](#create-java-model) create your Java model.
 1. [Design docx report](#design-docx-report) design your docx report with MS Word by using Velocity syntax to set fields to replace.
 1. [Generate docx report](#generate-docx-report) generate docx report by using XDocReport API.

If you wish to : 

 - use Docx with Freemarker, you could [download](http://code.google.com/p/xdocreport/downloads/list) 	**docxandfreemarker-`**`-sample.zip*.
 - use Docx with Velocity, you could [download](http://code.google.com/p/xdocreport/downloads/list) **docxandvelocity-`**`-sample.zip*.


# Add XDocReport JARs

XDocReport is very modular. It means that you can choose your document type (odt, docx...) as source report and use template engine syntax to set fields name (Freemarker/Velocity...).

In our case we will generate report from docx with Velocity. So we need to set well JARs in your classpath. Here screen of your Eclipse project (if you are using Eclipse) after adding XDocReport JARs : 

![](screenshots/DocxProjectWithVelocity_AddJARs.png)

## Required JARs

For any document type and template engine you need to add following JARs : 

<table>
  <tr><th>JARs name</th><th>Description</th><th>OSGi Bundle/Fragment</th></tr>
  <tr><td>fr.opensagres.xdocreport.core</td><td>XDocReport Core</td><td>Bundle</td></tr>
  <tr><td>fr.opensagres.xdocreport.document</td><td>Document type API</td><td>Bundle</td></tr>
  <tr><td>fr.opensagres.xdocreport.template</td><td>Template engine API</td><td>Bundle</td></tr>
  <tr><td>fr.opensagres.xdocreport.converter</td><td>Converter API</td><td>Bundle</td></tr>
</table>

## Docx Document JAR

In this section we wish using docx as document source for report, so you need to add Docx document implementation JAR: 

<table>
  <tr><th>JARs name</th><th>Description</th><th>OSGi Bundle/Fragment</th></tr>
  <tr><td>fr.opensagres.xdocreport.document.docx</td><td>Docx Document implementation</td><td>Fragment -> fr.opensagres.xdocreport.document</td></tr>
</table>

Note for OSGi : this JAR is a fragment linked to the bundle OSGi fr.opensagres.xdocreport.document.

## Velocity JARs

In this section we wish to use Velocity as syntax to set fields, so you need to add Velocity template engine implementation and Velocity JARs. 

### Velocity Template JAR

Add Velocity template engine implementation JAR: 

<table>
  <tr><th>JARs name</th><th>Description</th><th>OSGi Bundle/Fragment</th></tr>
  <tr><td>fr.opensagres.xdocreport.template.velocity</td><td>Velocity template engine implementation</td><td>Fragment -> fr.opensagres.xdocreport.template</td></tr>
</table>

Note for OSGi : this JAR is a fragment linked to the bundle OSGi fr.opensagres.xdocreport.template.

### Velocity JARs

Add Velocity JARs : 

<table>
  <tr><th>JARs name</th><th>Description</th></tr>
  <tr><td>velocity-1.7</td><td>Velocity</td></tr>
  <tr><td>commons-collections-3.2.1</td><td>Commons Collection</td></tr>
  <tr><td>commons-lang-2.4</td><td>Commons Lang</td></tr>
  <tr><td>oro-2.0.8</td><td>ORO</td></tr>
</table>

# Create Java model

Now you can create your Java model that you wish use in your docx report. In this section we will use Java Project model like this : 

```java
package fr.opensagres.xdocreport.samples.docxandvelocity.model;

public class Project {

  private final String name;

  public Project(String name) {
    this.name = name;
  }

  public String getName() {
    return name;
  }
}
```

# Design Docx report

At this step you can create your docx report with MS Word with the content : 

```
Project: $project.Name
```

![](screenshots/DocxProjectWithVelocity.png)

For the field to replace *$project.Name*, **DON'T type directly the field**  in your document otherwise you could have some troubles because MS Word escape your content. 

You must **use [MergeField](DocxDesignReport#create-mergefield-with-ms-word)** (Champs de fusion) and **not type directly** *$project.Name* in your documentation.

If you wish to use another template engine directive to manage condition, loop... like :

 - [#if, #foreach](http://velocity.apache.org/engine/releases/velocity-1.7/user-guide.html#Directives) ... for [Velocity](http://velocity.apache.org/).
 - [[#if, [#list...](http://freemarker.sourceforge.net/docs/ref_directives.html) for [Freemarker](http://freemarker.sourceforge.net/).

It's the same thing than field,  : DON'T type directly the directive*  in your document but use [MergeField](DocxDesignReport#create-mergefield-with-ms-word).

You can note for this sample that you can style field. If you don't know how create [MergeField](DocxDesignReport#create-mergefield-with-ms-word), please see [Docx Design Report](DocxDesignReport) section.

NOTE : for Freemarker, the square bracket syntax ([instead of <#if) must be used to have valid XML.

# Generate docx report

Once you have create docx, save it in your project. In this sample the docx report was saved with *DocxProjectWithVelocity.docx* name in the *fr.opensagres.xdocreport.samples.docxandvelocity* package of the Java project. 

Create Java class DocxProjectWithVelocity to load *DocxProjectWithVelocity.docx* and generate report in file *DocxProjectWithVelocity_Out.docx* like this :  

```java
package fr.opensagres.xdocreport.samples.docxandvelocity;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import fr.opensagres.xdocreport.core.XDocReportException;
import fr.opensagres.xdocreport.document.IXDocReport;
import fr.opensagres.xdocreport.document.registry.XDocReportRegistry;
import fr.opensagres.xdocreport.samples.docxandvelocity.model.Project;
import fr.opensagres.xdocreport.template.IContext;
import fr.opensagres.xdocreport.template.TemplateEngineKind;

public class DocxProjectWithVelocity {

  public static void main(String[](#if) args) {
    try {
      // 1) Load Docx file by filling Velocity template engine and cache it to the registry
      InputStream in = DocxProjectWithVelocity.class.getResourceAsStream("DocxProjectWithVelocity.docx");
      IXDocReport report = XDocReportRegistry.getRegistry().loadReport(in,TemplateEngineKind.Velocity);

      // 2) Create context Java model
      IContext context = report.createContext();
      Project project = new Project("XDocReport");
      context.put("project", project);

      // 3) Generate report by merging Java model with the Docx
      OutputStream out = new FileOutputStream(new File("DocxProjectWithVelocity_Out.docx"));
      report.process(context, out);

    } catch (IOException e) {
      e.printStackTrace();
    } catch (XDocReportException e) {
      e.printStackTrace();
    }
  }
}
```

Your Eclipse project looks like this : 

![](screenshots/DocxProjectWithVelocity_Workspace.png)

Run *DocxProjectWithVelocity* Java class and *DocxProjectWithVelocity_Out.docx* will be generated in your project home : 

![](screenshots/DocxProjectWithVelocity_WorkspaceOut.png)

If you open  **DocxProjectWithVelocity_Out.docx** you will see : 

![](screenshots/DocxProjectWithVelocity_Out.png)

# Test Performance

XDocReport uses Velocity/Freemarker cache to improve a lot the performance. To test performance, create  fr.opensagres.xdocreport.samples.docxandvelocity.*DocxProjectWithVelocityTestPerf* class like this which display time process for the first and second report generation : 

```java
package fr.opensagres.xdocreport.samples.docxandvelocity;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import fr.opensagres.xdocreport.core.XDocReportException;
import fr.opensagres.xdocreport.document.IXDocReport;
import fr.opensagres.xdocreport.document.registry.XDocReportRegistry;
import fr.opensagres.xdocreport.samples.docxandvelocity.model.Project;
import fr.opensagres.xdocreport.template.IContext;
import fr.opensagres.xdocreport.template.TemplateEngineKind;

public class DocxProjectWithVelocityTestPerf {

	public static void main(String[] args) {
		try {

			String reportId = "MyId";

			// 1) Load Docx file by filling Velocity template engine and cache
			// it to the registry
			InputStream in = DocxProjectWithVelocityTestPerf.class
					.getResourceAsStream("DocxProjectWithVelocity.docx");
			IXDocReport report = XDocReportRegistry.getRegistry().loadReport(
					in, reportId, TemplateEngineKind.Velocity);

			// 2) Create context Java model
			IContext context = report.createContext();
			Project project = new Project("XDocReport");
			context.put("project", project);

			// 3) Generate report by merging Java model with the Docx
			OutputStream out = new FileOutputStream(new File(
					"DocxProjectWithVelocity_Out.docx"));
			long start = System.currentTimeMillis();
			report.process(context, out);
			System.out.println("Report processed in "
					+ (System.currentTimeMillis() - start) + " ms");

			// 4) Regenerate report
			IXDocReport report2 = XDocReportRegistry.getRegistry().getReport(
					reportId);
			out = new FileOutputStream(new File(
					"DocxProjectWithVelocity_Out.docx"));
			start = System.currentTimeMillis();
			report2.process(context, out);
			System.out.println("Report processed in "
					+ (System.currentTimeMillis() - start) + " ms");

		} catch (IOException e) {
			e.printStackTrace();
		} catch (XDocReportException e) {
			e.printStackTrace();
		}
	}
}
```

Run **DocxProjectWithVelocityTestPerf** Java class and **DocxProjectWithVelocity_Out.docx** will be generated twice and console display time process : 

```
Report processed in 250 ms
Report processed in 16 ms
```

You can notice that the second report generation is very quick. This time is explained with use of velocity cache which cache the XML entry to merge with Java model.

Here report is loaded by filling an id : 

```java
String reportId = "MyId";

// 1) Load Docx file by filling Velocity template engine and cache
// it to the registry
InputStream in = DocxProjectWithVelocityTestPerf.class.getResourceAsStream("DocxProjectWithVelocity.docx");
```

The report is retrieved form the registry with this code : 

```java
IXDocReport report2 = XDocReportRegistry.getRegistry().getReport(reportId);
```

# More features

 - [Docx Reporting Java Main List Field](DocxReportingJavaMainListField), if you wish manage loop for fields.
 - [Docx Reporting Java Main Converter](DocxReportingJavaMainConverter), if you wish convert report 2 PDF/XHTML.
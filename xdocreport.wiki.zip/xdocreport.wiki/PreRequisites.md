# Prerequisites

 - a decent IDE :
   - We currently use eclipse 3.7 "Eclipse for RCP and RAP Developers" (see: http://www.eclipse.org/downloads/)
 - maven 2+
   - We use m2eclipse (maven addons for eclipse) which is available from the eclipse maketplace.
 - git
   - We use EGit which is bundle with eclipse or available from eclipse marketplace.
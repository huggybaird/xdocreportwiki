# ODT Reporting in Java Main

This section explains step by step how generate a report created with OpenOffice ODT by using Velocity syntax to set fields to replace. 

We will create a basic odt document *ODTProjectWithVelocity.odt* : 

![](screenshots/ODTProjectWithVelocity.png)

The _$project.Name_ is an input field and project is Java model Project class which define _Project#getName()_. The field name start with _project_ because we will register the Java Model with _project_ key in the context like this : 

```
Project project = new Project("XDocReport");
context.put("project", project);
```

After report process we will generate the document _ODTProjectWithVelocity_Out.odt_ : 

![](screenshots/ODTProjectWithVelocity_Out.png)

Steps section are : 

 1. [Add XDocReport JARs](#1._Add_XDocReport_JARs) in your classpath project.
 1. [Create Java model](#2._Create_Java_model) create your Java model.
 1. [Design odt report](#3._Design_ODT_report) design your odt report with OpenOffice by using Velocity syntax to set fields to replace.
 1. [Generate odt report](#4._Generate_odt_report) generate odt report by using XDocReport API.

If you wish to : 

 - use ODT with Freemarker, you could [download](http://code.google.com/p/xdocreport/downloads/list) 	**odtandfreemarker-`**`-sample.zip*.
 - use ODT with Velocity, you could [download](http://code.google.com/p/xdocreport/downloads/list) **odtandvelocity-`**`-sample.zip*.

# 1. Add XDocReport JARs

XDocReport is very modular. It means that you can choose your document type (docx, odt...) as source report and use template engine syntax to set fields name (Freemarker/Velocity...).

In our case we will generate report from odt with Velocity. So we need to set well JARs in your classpath. Here screen of your Eclipse project (if you are using Eclipse) after adding XDocReport JARs : 

[## Required JARs

For any document type and template engine you need to add following JARs : 

<table>
  <tr><td>*JARs name*</td><td>*Description*</td><td>*OSGi Bundle/Fragment*</td></tr>
  <tr><td>fr.opensagres.xdocreport.core</td><td>XDocReport Core</td><td>Bundle</td></tr>
  <tr><td>fr.opensagres.xdocreport.document</td><td>Document type API</td><td>Bundle</td></tr>
  <tr><td>fr.opensagres.xdocreport.template</td><td>Template engine API</td><td>Bundle</td></tr>
  <tr><td>fr.opensagres.xdocreport.converter</td><td>Converter API</td><td>Bundle</td></tr>
  <tr><td>commons-io-1.4</td><td>Commons IO</td></tr>
</table>

## ODT Document JAR

In this section we wish using odt as document source for report, so you need to add ODT document implementation JAR: 

<table>
  <tr><td>*JARs name*</td><td>*Description*</td><td>*OSGi Bundle/Fragment*</td></tr>
  <tr><td>fr.opensagres.xdocreport.document.odt</td><td>ODT Document implementation</td><td>Fragment -> fr.opensagres.xdocreport.document</td></tr>
</table>

Note for OSGi : this JAR is a fragment linked to the bundle OSGi fr.opensagres.xdocreport.document.

## Velocity JARs

In this section we wish using Velocity as syntax to set fields, so you need to add Velocity template engine implementation and Velocity JARs. 

### Velocity Template JAR

Add Velocity template engine implementation JAR: 

<table>
  <tr><td>*JARs name*</td><td>*Description*</td><td>*OSGi Bundle/Fragment*</td></tr>
  <tr><td>fr.opensagres.xdocreport.template.velocity</td><td>Velocity template engine implementation</td><td>Fragment -> fr.opensagres.xdocreport.template</td></tr>
</table>

Note for OSGi : this JAR is a fragment linked to the bundle OSGi fr.opensagres.xdocreport.template.

### Velocity JARs

Add Velocity JARs : 

<table>
  <tr><td>*JARs name*</td><td>*Description*</td></tr>
  <tr><td>velocity-1.7</td><td>Velocity</td></tr>
  <tr><td>commons-collections-3.2.1</td><td>Commons Collection</td></tr>
  <tr><td>commons-lang-2.4</td><td>Commons Lang</td></tr>
  <tr><td>oro-2.0.8</td><td>ORO</td></tr>
</table>

# 2. Create Java model

Now you can create your Java model that you wish use in your odt report. In this section we will use Java Project model like this : 

```java
package fr.opensagres.xdocreport.samples.odtandvelocity.model;

public class Project {

  private final String name;

  public Project(String name) {
    this.name = name;
  }

  public String getName() {
    return name;
  }
}
```

# 3. Design ODT report

At this step you can create your odt report with OpenOffice with the content : 

`Project: $project.Name`

![](screenshots/ODTProjectWithVelocity.png)(http://wiki.xdocreport.googlecode.com/git/screenshots/ODTProjectWithVelocity_AddJARs.png))

For the field to replace *$project.Name*, it is advice to use Input-Field and not to type directly *$project.Name* in your documentation (TODO : explain why).

You can note for this sample that you can style field. If you don't know how create Input-Field, please see [ODT Design Report](ODTDesignReport) section.

# 4. Generate odt report

Once you have create odt, save it in your project. In this sample the odt report was saved with **ODTProjectWithVelocity.odt** name in the **fr.opensagres.xdocreport.samples.odtandvelocity** package of the Java project. 

Create Java class ODTProjectWithVelocity to load **ODTProjectWithVelocity.odt** and generate report in file **ODTProjectWithVelocity_Out.odt** like this :  

```java
package fr.opensagres.xdocreport.samples.odtandvelocity;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import fr.opensagres.xdocreport.core.XDocReportException;
import fr.opensagres.xdocreport.document.IXDocReport;
import fr.opensagres.xdocreport.document.registry.XDocReportRegistry;
import fr.opensagres.xdocreport.samples.odtandvelocity.model.Project;
import fr.opensagres.xdocreport.template.IContext;
import fr.opensagres.xdocreport.template.TemplateEngineKind;

public class ODTProjectWithVelocity {

  public static void main(String[args) {
    try {
      // 1) Load ODT file by filling Velocity template engine and cache it to the registry
      InputStream in = ODTProjectWithVelocity.class.getResourceAsStream("ODTProjectWithVelocity.odt");
      IXDocReport report = XDocReportRegistry.getRegistry().loadReport(in,TemplateEngineKind.Velocity);

      // 2) Create context Java model
      IContext context = report.createContext();
      Project project = new Project("XDocReport");
      context.put("project", project);

      // 3) Generate report by merging Java model with the ODT
      OutputStream out = new FileOutputStream(new File("ODTProjectWithVelocity_Out.odt"));
      report.process(context, out);

    } catch (IOException e) {
      e.printStackTrace();
    } catch (XDocReportException e) {
      e.printStackTrace();
    }
  }
}
```

Your Eclipse project looks like this : 

![](screenshots/ODTProjectWithVelocity_Workspace.png)(])

Run **ODTProjectWithVelocity** Java class and **ODTProjectWithVelocity_Out.odt** will be generated in your project home : 

[If you open  *ODTProjectWithVelocity_Out.odt* you will see : 

![](screenshots/ODTProjectWithVelocity_Out.png)(http://wiki.xdocreport.googlecode.com/git/screenshots/ODTProjectWithVelocity_WorkspaceOut.png))

# More features

 - [List Field](ODTReportingJavaMainListField), if you wish manage loop for fields.
 - [Converter (PDF/XHTML)](ODTReportingJavaMainConverter), if you wish convert report 2 PDF/XHTML.
# Getting Started

XDocReport give you the capability to **generate report from odt, docx** files by using **template engine syntax** (Freemarker, velocity...) and **convert it to another format** (XHTML, PDF...). 

Converters can be used **while report generation** and in **standalone mode** to just convert documents.

This guide provides information about: 

 - [Overview](Overview): this section give you an overview about XDocReport.
 - [Developers Guide](DevelopersGuide): this guide is intended to help Java developer to integrate XDocReport in your application.
  - [Reporting](Reporting) : section which explains how integrate XDocReport reporting features (with or without conversion) in your application.
  - [Converters](Converters) : section which explains how integrate XDocReport converter features in your application.
 - [User's Guide](UsersGuide): this guide is intended to help report designers who create OpenOffice/MS Word document with Freemarker/Velocity syntax to set the fields to replace while report generation.
 - [FAQ](FAQ): "Frequently Asked Questions" about XDocReport.
 - [Releases](Releases) : download XDocReport.
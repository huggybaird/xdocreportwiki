# One-sentence summary of this page.

# User's Guide

This guide is intended to help report designers who create OpenOffice/MS Word document with Freemarker/Velocity syntax to set the fields to replace while report generation.
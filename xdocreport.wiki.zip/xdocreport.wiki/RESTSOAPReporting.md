See demo at  http://xdocreport-reporting.opensagres.eu.cloudbees.net

WADL :  http://xdocreport-reporting.opensagres.eu.cloudbees.net/jaxrs/report?_wadl

Java project: http://code.google.com/p/xdocreport/source/browse/#git%2Fremoting%2Ffr.opensagres.xdocreport.remoting.reporting.server

Java demo : http://code.google.com/p/xdocreport/source/browse?repo=samples#git%2FREST-Service-Reporting-WebApplication

Python client : https://github.com/silviot/xdocreport_restclient
# XDocReport with Play!

XDocReport provides a XDocReport module for [Play!](http://www.playframework.org/) framework to generate report with docx, odt and convert it to another format PDF/XHTML if you wish. 

 - for Play version 1.0, please go at [https://github.com/opensagres/play-xdocreport](https://github.com/opensagres/play-xdocreport)
 - for Play version 2.0, TODO develop that.
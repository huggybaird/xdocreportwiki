# Developer's Guide

This guide is intended to help Java developer to integrate XDocReport in your application switch context (Java main, WEB context, OSGi context...)

This guide provides information about: 

 - [[Reporting|Reporting]] : section which explains how integrate XDocReport reporting features (with or without conversion) in your application.
 - [[Converters|Converters]] : section which explains how integrate XDocReport converter features in your application.
# Docx Design Report

XDocReport give you the capability to **create report with MS Word docx**. Fields to replace must follow **Freemarker/Velocity syntax**. Typing directly field name can work, but you can have trouble if you style the field. So it is advisable to **use MergeField to set fields to replace**.

To add **MergeField** in your docx report you can: 

 - [Use standard MS Word MergeField](#create-mergefield-with-ms-word) creation.
 - [Docx Design Report Macro](DocxDesignReportMacro) which display in a dialog box fields available for the model.

To [manage Dynamic Image](#manage-dynamic-image) in your docx report you must : 

 - insert a "template" image (any image).
 - set a name for the image by using Bookmark.

For the "template" image you can for instance use this image : ![](screenshots/template.png)

# Create MergeField with MS Word

This section explains how to add MergeField *$project.Name* after Project: content. Here steps to add this MergeField : 

 - Do *Ctrl+F9* after Project: content :

![](screenshots/DocxCreateMergeField1.png).

 - MS Word generate you **{ }**. Select it and click on right mouse to open contextual menu and select **Field modification...** (Modification du champs...) menu:

 - this action opens the Field dialog. Select *MergeField tree item* (ChampsFusion) :

![](screenshots/DocxCreateMergeField3.png)

 - Select **MergeField tree item** (Champs de fusion) and type **$project.Name** in the field name (Nom du champs) and click on OK button :

 - MergeField is created :

![](screenshots/DocxCreateMergeField5.png)

 - Now you can style it if you wish. To do that, select the whole mergefield :

 - Style it as you wish :

![](screenshots/DocxCreateMergeField7.png)

# Manage Dynamic Image

This section explains how to add Dynamic Image **$logo** in a docx document. Here steps to add this dynamic image : 

 - go to the menu **Insert/Image** (Insertion/Image) :

- this action opens the dialog to select an image. In this screenshot, template.png ![](screenshots/template.png) is selected:

- after clicking on *Insert* button, image is inserted in the document. Now you must name the image. To do that, we must link with the image a bookmark named with *logo*. To do that, select the image, click on *Insert/Bookmark* (Insertion/Signet) :

![](screenshots/DocxCreateDynamicImage3.png)

 - this action opens the bookmark dialog box. Type **logo** in the **bookmark name** input field and on **Add** button: Dynamic image is now available with *logo* name.

 - You can go to the Bookmark to select the linked image with Bookmark Dialog:

![](screenshots/DocxCreateDynamicImage5.png)
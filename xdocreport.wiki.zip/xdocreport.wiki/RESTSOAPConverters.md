See demo at http://xdocreport-converter.opensagres.cloudbees.net/

WADL : http://xdocreport-converter.opensagres.cloudbees.net/jaxrs/report?_wadl

Java project: http://code.google.com/p/xdocreport/source/browse/#git%2Fremoting%2Ffr.opensagres.xdocreport.remoting.converter.server

Java demo : http://code.google.com/p/xdocreport/source/browse?repo=samples#git%2FREST-Service-Converter-WebApplication
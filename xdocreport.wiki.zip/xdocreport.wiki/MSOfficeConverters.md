# MS Office Converters

## Docx Converters

Here the list of XDocReport fr.opensagres.xdocreport.converter.**IConverter** implemented for docx which can be used with ConverterRegistry? :

### Stable Docx Converter

<table>
  <tr><td>ID</td><td>Output format</td><td>OSGi fragment (Git Link)</td><td>Dependencies</td><td>Status</td></tr>
  <tr><td>Docx 2 PDF via POI-IText</td><td>PDF</td><td>[fr.opensagres.xdocreport.converter.docx.xwpf](http://code.google.com/p/xdocreport/source/browse/#git%2Fconverter%2Ffr.opensagres.xdocreport.converter.docx.xwpf)</td><td>Apache POI + iText</td><td>Stable</td></tr>
  <tr><td>Docx 2 XHTML via POI</td><td>XHTML</td><td>[fr.opensagres.xdocreport.converter.docx.xwpf](http://code.google.com/p/xdocreport/source/browse/#git%2Fconverter%2Ffr.opensagres.xdocreport.converter.docx.xwpf)</td><td>Apache POI</td><td>Stable</td></tr>
  <tr><td>Docx 2 PDF via docx4j</td><td>XHTML</td><td>[fr.opensagres.xdocreport.converter.docx.docx4j](http://code.google.com/p/xdocreport/source/browse/#git%2Fconverter%2Ffr.opensagres.xdocreport.converter.docx.docx4j)</td><td>docx4j + FOP</td><td>Stable</td></tr>
  <tr><td>Docx 2 XHTML via docx4j</td><td>XHTML</td><td>[fr.opensagres.xdocreport.converter.docx.docx4j](http://code.google.com/p/xdocreport/source/browse/#git%2Fconverter%2Ffr.opensagres.xdocreport.converter.docx.docx4j)</td><td>docx4j</td><td>Stable</td></tr>
</table>

After several experimentation (see converters below), we decided to keep "Docx 2 PDF via POI-IText" because "Docx 2 PDF via FOP" converter are more slowly than "Docx 2 PDF via POI-IText" because steps are docx -> XSL-FO -> FO -> FOP. 

[fr.opensagres.xdocreport.converter.docx.xwpf](http://code.google.com/p/xdocreport/source/browse/#git%2Fconverter%2Ffr.opensagres.xdocreport.converter.docx.xwpf) is based on the [org.apache.poi.xwpf.converter](XWPFConverter) which is enable to convert :

 - docx to PDF.
 - docx to XHTML.

Here the process of [org.apache.poi.xwpf.converter](XWPFConverter) converter for PDF conversion :

 1. load docx in Java Structure [Apache POI - HWPF](http://poi.apache.org/hwpf/index.html) org.apache.poi.xwpf.usermodel.**XWPFDocument**
 1. loop for each POI Java model (paragraph, table, etc) and create for each POI model a PDF [iText](http://itextpdf.com/) model.
### Experimental Docx Converter

Here converters use FOP and XSL to transform document.xml (by using styles.xml) from the docx to FO or XHTML. 

<table>
  <tr><td>ID</td><td>Output format</td><td>OSGi fragment (Git Link)</td><td>Status</td></tr>
  <tr><td>Docx 2 PDF via FOP</td><td>PDF</td><td>[fr.opensagres.xdocreport.converter.fop.docx](http://code.google.com/p/xdocreport/source/browse/#git%2Fsandbox%2Ffr.opensagres.xdocreport.converter.fop.docx)</td><td>Experimental</td></tr>
  <tr><td>Docx 2 FO via XSL-FO</td><td>FO</td><td>[fr.opensagres.xdocreport.converter.fop.docx](http://code.google.com/p/xdocreport/source/browse/#git%2Fsandbox%2Ffr.opensagres.xdocreport.converter.fop.docx)</td><td>Experimental</td></tr>
  <tr><td>Docx 2 XHTML via XSL</td><td>XHTML</td><td>[fr.opensagres.xdocreport.converter.fop.docx](http://code.google.com/p/xdocreport/source/browse/#git%2Fsandbox%2Ffr.opensagres.xdocreport.converter.fop.docx)</td><td>Experimental</td></tr>
</table>